#pragma once
#include "node.h"

#define MAXL 10

class List
{
    int size, SIZE, counter;
    Node* tail, * current, *cut;
public:
    Node* head;
    List();
    bool IsEmpty();
    bool IsFull();
    void Insert(string nick);
    void Remove(string nick);
    bool Search(string nick);
    int GetSize();
    void Print();
};


List::List()
{
    head = new Node [MAXL];
    cut = head;
    tail = head;
	for(int i = 1; i < MAXL; i++)
	{
		tail->next = tail + 1;
		(tail + 1)->prev = tail;
		tail = tail->next;
	}
    current = head;
	size = 0;
    counter = 0;
    SIZE = MAXL;
}

bool List::IsEmpty()
{
    return (!size);
}

bool List::IsFull()
{
	return (size == SIZE);
}

void List::Insert(string nick)
{
    if(IsFull())
    {
        tail->next = new Node [MAXL];
        tail->next->prev = tail;
        tail = tail->next;
        current = tail;
        for(int i = 1; i < MAXL; i++)
        {   
            tail->next = tail + 1;
            (tail + 1)->prev = tail;
            tail = tail->next;
        }
        SIZE += MAXL;
    }
    current->nick = nick;
	current = current->next;
    size++;
    return;
}

bool List::Search(string nick)
{
    int i = 0;
    for (Node* cur = head; i < size; cur = cur->next)
    {
        if (cur->nick == nick)
        {
            return true;
        }
        i++;
    }
    return false;
}

void List::Remove(string nick)
{
    if (nick == head->nick)
    {       
        head = head->next;
        counter++;
        if(counter == MAXL)
        {  
           Node* toCut = cut;
           delete [] toCut;
           cut = head;
           counter = 0;
        }
    }
    else
    {
        Node* temp = head;
        while (temp->next->nick != nick)
        {
            temp = temp->next;
        }
        temp->next = temp->next->next;
    }
    SIZE--;
    size--;
    return;
}

int List::GetSize()
{
    return size;
}

void List::Print()
{
    if (IsEmpty())
    {
        return;
    }
    int i = 1;
    for(Node* cur = head; i < size + 1; cur = cur->next)
    {
		cout << cur->nick << endl;
		i++;
    }
    return;
}
