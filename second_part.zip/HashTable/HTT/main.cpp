#include "UI.h"

int main() 
{   
    ifstream fin("input.txt");
    HashTable ht;
    string nick;
    for(int i = 1; i <= 1000000; i++)
    {
        fin >> nick;
        ht.insert(nick);
    }
    while (UI(ht)); 
    return 0;
}
