#pragma once
#include "list.h"

#define MAX 1000000

class HashTable
{
    List* table;
public:
    HashTable();
    ~HashTable();
    int Hash(string nick);
    int GetSize();
    void Search(string nick);
    void Insert(string nick);
    void insert(string nick);
    void Remove(string nick);
    void Print();
};

HashTable::HashTable()
{
    table = new List [MAX];
}

HashTable::~HashTable()
{
    delete [] table;
}

int HashTable::Hash(string nick)
{
    return nick[0] % MAX;
}

int HashTable::GetSize()
{
	int sum = 0;
    for(int i = 0; i < MAX; i++) 
    {
        sum += table[i].GetSize();
    }
    return sum;
}

void HashTable::Search(string nick)
{
    int hash = Hash(nick);
    int counter = 0;
    string* temp = new string[4];
    Node* cur = table[hash].head;
    if(table[hash].Search(nick))
    {
        temp[0] = nick;
        counter++;
    }
    for(int i = 0; i < table[hash].GetSize(); i++)
    {
        if(cur->nick.substr(0, nick.size()) == nick)
        {
            if(cur->nick == nick)
            {
                cur = cur->next;
                continue;          
            }
            if(counter < 4)
            {
                temp[counter] = cur->nick;
            }
            counter++;
        }
        cur = cur->next;
    }
    if(counter == 0)
    {
        cout << "#0" << endl;
    }
    else if(counter < 5)
    {
        for(int i = 0; i < counter; i++)
        {
            cout << temp[i] << " ";
        }
        cout << endl;
    }
    else
    {
        for(int i = 0; i < 3; i++)
        {
            cout << temp[i] << " ";
        }
        cout << "#" << counter - 3 << endl;
    }
    delete [] temp;
    return;
}

void HashTable::Insert(string nick)
{
    int hash = Hash(nick);
    if(table[hash].Search(nick))
    {
        cout << "ERROR: +" << nick << endl;
        return;
    }
    table[hash].Insert(nick);
    return;
}

void HashTable::insert(string nick)	// Нужен, чтобы не уходило много времени на вставку тестовых ников в самом начале программы
{
    int hash = Hash(nick);
    table[hash].Insert(nick);
    return;
}

void HashTable::Remove(string nick)
{
    int hash = Hash(nick);
    if (!table[hash].Search(nick))
    {
        cout << "ERROR: -" << nick << endl;
        return;
    }
    table[hash].Remove(nick);
    return;
}

void HashTable::Print()
{
    cout << "Nicknames:" << endl;
    for(int i = 0; i < MAX; i++)
    {
        table[i].Print();
    }
    return;
}
