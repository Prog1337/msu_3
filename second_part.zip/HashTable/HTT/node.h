#pragma once
#include <iostream>
#include <string>
#include <ctime>
#include <fstream>
using namespace std;

class Node
{
public:
    string nick;
    Node* next, * prev;
    Node(string nick = " ", Node* next = nullptr, Node* prev = nullptr)
    {
        this->nick = nick;
        this->next = next;
        this->prev = prev;
    }
};