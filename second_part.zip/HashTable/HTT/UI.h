#pragma once
#include "hashtable.h"

int UI(HashTable& ht)
{
	double t_full;
	char choice;
    string nick;
    system("cls");
	cout << "::::::::::::::::::::::::::::::::::::" << endl;
	cout << "::::::::::::" << "\t+user\t" << "::::::::::::" << endl;
	cout << "::::::::::::" << "\t-user\t" << "::::::::::::" << endl;
	cout << "::::::::::::" << "\t?user\t" << "::::::::::::" << endl;
	cout << "::::::::::::" << "\t!show\t" << "::::::::::::" << endl;
	cout << "::::::::::::" << "\t#qnty\t" << "::::::::::::" << endl;
	cout << "::::::::::::" << "\t~exit\t" << "::::::::::::" << endl;
	cout << "::::::::::::::::::::::::::::::::::::" << endl;
	cout << endl; 
	cin >> choice;
	if(choice == '~')
	{
		system("cls");
		cout << "Exit." << endl;
		return 0;
	}
	if(choice == '!')
	{
		system("cls");
		ht.Print();
		system("pause");
		return 1;
	}
	if(choice == '#')
	{
		system("cls");
		cout << ht.GetSize() << endl;
		system("pause");
		return 1;
	}
	cin >> nick;
	system("cls");
	switch(choice) 
    {
		case '+' :
			t_full = clock();
			ht.Insert(nick);
			t_full = clock() - t_full;
			t_full /= CLOCKS_PER_SEC;
			cout << "Total full time : " << t_full << endl;
			system("pause");
			return 1;
		
		case '-' :
			t_full = clock();
			ht.Remove(nick);
			t_full = clock() - t_full;
			t_full /= CLOCKS_PER_SEC;
			cout << "Total full time : " << t_full << endl;
			system("pause");
			return 1;
			
		case '?' :
			t_full = clock();
			ht.Search(nick);
			t_full = clock() - t_full;
			t_full /= CLOCKS_PER_SEC;
			cout << "Total full time : " << t_full << endl;
			system("pause");
			return 1;
			
		default : 
			cout << "Unknown command." << endl;
			system("pause");
			return 1;
	}
}
