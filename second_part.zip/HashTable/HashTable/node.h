#pragma once
#include <iostream>
#include <string>
using namespace std;

class Node
{
public:
    string nick;
    Node* next;
    Node(string nick = " ", Node* next = nullptr)
    {
        this->nick = nick;
        this->next = next;
    }
};