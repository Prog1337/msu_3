
#pragma once
#include "list.h"

#define MAX 1000000

class HashTable
{
    List* table;
public:
    HashTable();
    ~HashTable();
    bool IsEmpty();
    bool IsFull();
    int Hash(string nick);
    bool IsExist(string nick);
    void Search(string nick);
    void Insert(string nick);
    void Remove(string nick);
    void Print();
};

HashTable::HashTable()
{
    table = new List [MAX];
}

HashTable::~HashTable()
{
    delete [] table;
}

bool HashTable::IsEmpty()
{
    int sum = 0;
    for(int i = 0; i < MAX; i++) 
    {
        sum += table[i].GetSize();
    }
    return !sum;
}

int HashTable::Hash(string nick)
{
    return nick[0] % MAX;
}

bool HashTable::IsExist(string nick)
{
    for(int i = 0; i < MAX; i++)
    {
        if(table[i].Search(nick))
        {
            return true;
        }
    }
    return false;
}

void HashTable::Search(string nick)
{
    int hash = Hash(nick);
    int counter = 0;
    string* temp = new string[4];
    if(table[hash].Search(nick))
    {
        temp[0] = nick;
        counter++;
    }
    for(int i = 0; i < table[hash].GetSize(); i++)
    {
        if(((table[hash])[i].substr(0, nick.size())) == nick)
        {
            if((table[hash])[i] == nick)
            {
                continue;          
            }
            if(counter < 4)
            {
                temp[counter] = (table[hash])[i];
            }
            counter++;
        }
    }
    if(counter == 0)
    {
        cout << "[ERROR] #0" << endl;
    }
    else if(counter < 5)
    {
        for(int i = 0; i < counter; i++)
        {
            cout << temp[i] << " ";
        }
        cout << endl;
    }
    else
    {
        for(int i = 0; i < 3; i++)
        {
            cout << temp[i] << " ";
        }
        cout << "#" << counter - 3 << endl;
    }
    delete [] temp;
    return;
}

void HashTable::Insert(string nick)
{
    int hash = Hash(nick);
    if(table[hash].Search(nick))
    {
        cout << "[ERROR] +" << nick << endl;
        return;
    }
    table[hash].Insert(nick);
    return;
}

void HashTable::Remove(string nick)
{
    int hash = Hash(nick);
    table[hash].Remove(nick);
    return;
}

void HashTable::Print()
{
    cout << "Nicknames:" << endl;
    for(int i = 0; i < MAX; i++)
    {
        table[i].Print();
    }
    return;
}