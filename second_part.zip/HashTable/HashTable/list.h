#pragma once
#include "node.h"

class List
{
    int size;
    Node* head;
public:
    List();
    ~List();
    bool IsEmpty();
    void Insert(string nick);
    void Remove(string nick);
    bool Search(string nick);
    string& operator [] (const int index);
    void Clear();
    int GetSize();
    void Print();
};


List::List()
{
    head = nullptr;
    size = 0;
}

List::~List()
{
    Clear();
}

bool List::IsEmpty()
{
    return (!size);
}

void List::Insert(string nick)
{
    if (!head)
    {
        head = new Node(nick);
    }
    else
    {
        Node* temp = head;
        while (temp->next)
        {
            temp = temp->next;
        }
        temp->next = new Node(nick);
    }
    size++;
    return;
}

bool List::Search(string nick)
{
    for (int i = 0; i < size; i++)
    {
        if ((*this)[i] == nick)
        {
            return true;
        }
    }
    return false;
}

void List::Remove(string nick)
{
    if (!Search(nick))
    {
        cout << "[ERROR] -" << nick << endl;
        return;
    }
    Node* cur = head;
    if (nick == head->nick)
    {
        head = head->next;
        delete cur;
    }
    else
    {
        while (cur->next->nick != nick)
        {
            cur = cur->next;
        }
        Node* temp = cur->next;
        cur->next = temp->next;
        delete temp;
    }
    size--;
    return;
}

string& List::operator [] (const int index)
{
    Node* cur = head;
    int counter = 0;
    while (cur->next)
    {
        if (counter == index)
        {
            return cur->nick;
        }
        cur = cur->next;
        counter++;
    }
    return cur->nick;
}

void List::Clear()
{
    for (int i = size; size; i++)
    {
        Remove((*this)[i]);
    }
}

int List::GetSize()
{
    return size;
}

void List::Print()
{
    if (IsEmpty())
    {
        return;
    }
    for (int i = 0; i < size; i++)
    {
        cout << (*this)[i] << endl;
    }
    return;
}