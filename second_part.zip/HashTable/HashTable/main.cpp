#include "UI.h"

int main()
{   
    HashTable ht;
    string s;
    int i = 0;
    for(i = 0; i < 500000; i++)
    {
        ht.Insert("ABC" + to_string(i));
        cout << i << endl;
    }
    while (UI(ht));
    return 0;
}