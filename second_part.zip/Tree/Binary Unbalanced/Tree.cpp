#include <iostream>
using namespace std;

int tabs = 0;

class Vertex
{
public:
	int data;
	Vertex* left, * right;
	Vertex(int data)
	{
		this->data = data; 
		left = nullptr;
		right = nullptr;
	}
};

class Tree
{
public:
	Tree();
	~Tree();
	Vertex* root;
	Vertex* Insert(int data, Vertex* pos);
	Vertex* Delete(int data, Vertex* pos);
	Vertex* BinaryTree(Vertex* pos);
	bool Find(int data, Vertex* pos);
	int FindMin(Vertex* pos);
	int FindMax(Vertex* pos);
	void Print(Vertex* pos);
};

Tree::Tree()
{
	cout << "Creating the tree..." << endl;
	root = nullptr;
	cout << "Tree was created." << endl;
}

Tree::~Tree()
{
	cout << "Deleting the tree..." << endl;
	for(int i = FindMin(root); i < FindMax(root); i++)
	{
		Delete(i, root);
	}
	cout << "The tree was deleted." << endl;

}
Vertex* Tree::Insert(int data, Vertex* pos)
{
	if (!pos)
	{
		Vertex* temp = new Vertex(data);
		pos = temp;
		if (!pos) return nullptr;
	}
	else
	{
		if (data > pos->data)
		{
			pos->right = Insert(data, pos->right);
			if (!pos->right) return nullptr;
		}
		if(data < pos->data)
		{
			pos->left = Insert(data, pos->left);
			if (!pos->left) return nullptr;
		}
	}
	return pos;
}

Vertex* Tree::Delete(int data, Vertex* pos)
{
	if(!pos)
	{
		return nullptr;
	}
	if(data == pos->data)
	{
		Vertex* temp;
		if(!pos->left)
		{	
			temp = pos->right;
			delete pos;
			return temp;
		}
		if (!pos->right)
		{ 
			temp = pos->left;
			delete pos;
			return temp;
		}
		for(temp = pos->left; temp->right; temp = temp->right);
		pos->data = temp->data;
		pos->left = Delete(temp->data, pos->left);
	}
	else
	{
		if(data < pos->data)
		{
			pos->left = Delete(data, pos->left);
		}
		else
		{
			pos->right = Delete(data, pos->right);
		}
	}
	return pos;
}

Vertex* Tree::BinaryTree(Vertex* pos)
{
	if (!pos)
    {
        
        BinaryTree(node->left);
        BinaryTree(node->right);
    }
}

bool Tree::Find(int data, Vertex* pos)
{
	if(!pos)
	{
		return false;
	}
	if(data > pos->data)
	{
		return Find(data, pos->right);
	}
	else
	{
		if(data < pos->data)
		{
			return Find(data, pos->left);
		}
		else
		{
			return true;
		}
	}
}

int Tree::FindMin(Vertex* pos)
{
	if(!pos)
	{
		return 0;
	}
	Vertex* temp = pos;
	while(temp->left)
		temp = temp->left;
	return temp->data;
}


int Tree::FindMax(Vertex* pos)
{
	if(!pos)
	{
		return 0;
	}
	Vertex* temp = pos;
	while(temp->right)
		temp = temp->right;
	return temp->data;
}

void Tree::Print(Vertex* pos)
{
	if (!pos) return;
	tabs += 5;

	Print(pos->right);

	for (int i = 0; i < tabs; i++) cout << " ";
	cout << pos->data << endl;

	Print(pos->left);

	tabs -= 5;
	return;
}

int UI(Tree& tree, int choice = 0)
{
	int value;
	system("cls");
	cout << "::::::::::::::::::::::::::::::::::::::::::::::::::::::" << endl;
	cout << "::::::::::::" << "\t 1. Insert the vertex. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 2. Delete the vertex. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 3. Find the vertex. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 4. Find the minimum. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 5. Find the maximum. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 6. Print the tree. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 0. Exit. \t\t" << "  ::::::::::::" << endl;
	cout << "::::::::::::::::::::::::::::::::::::::::::::::::::::::" << endl;
	cout << endl;
	cout << "Choose the command : ";
	cin >> choice;
	system("cls");
	switch (choice)
	{
	case 0:
		return 0;

	case 1:
		cout << "Enter the value of the vertex : ";
		cin >> value;
		if(tree.Find(value, tree.root))
		{
			system("cls");
			cout << "Such vertex already exists." << endl;
		}
		tree.root = tree.Insert(value, tree.root);
		system("pause");
		return 1;

	case 2:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "Enter the value of the vertex : ";
		cin >> value;
		if(!tree.Find(value, tree.root))
		{
			system("cls");
			cout << "Such vertex does NOT exist." << endl;
		}
		tree.root = tree.Delete(value, tree.root);
		system("pause");
		return 1;
	
	case 3:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "Enter the value of the vertex : ";
		cin >> value;
		system("cls");
		tree.Find(value, tree.root) ? cout << "There is such vertex." : cout << "There is NOT such vertex.";
		cout << endl;
		system("pause");
		return 1;
		
	case 4:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "The smallest vertex : " << tree.FindMin(tree.root) << endl;
		system("pause");
		return 1;
		
	case 5:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "The largest vertex : " << tree.FindMax(tree.root) << endl;
		system("pause");
		return 1;
	
	case 6:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		else
		{
			cout << "\tTree" << endl << endl;
			tree.Print(tree.root);
			cout << endl;
		}
		system("pause");
		return 1;

	default:
		cout << "Unknown command." << endl;
		system("pause");
		return 1;
	}
}

int main()
{
	Tree tree;
	while (UI(tree));
	return 0;
}
