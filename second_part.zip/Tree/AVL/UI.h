#pragma once
#include "AVLTree.h"

int UI(AVL& tree)
{
	int choice, value;
	system("cls");
	cout << "::::::::::::::::::::::::::::::::::::::::::::::::::::::" << endl;
	cout << "::::::::::::" << "\t 1. Insert the vertex. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 2. Delete the vertex. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 3. Find the vertex. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 4. Find the minimum. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 5. Find the maximum. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 6. Print the tree. \t" << "  ::::::::::::" << endl;
	cout << "::::::::::::" << "\t 0. Exit. \t\t" << "  ::::::::::::" << endl;
	cout << "::::::::::::::::::::::::::::::::::::::::::::::::::::::" << endl;
	cout << endl;
	cout << "Choose the command : ";
	cin >> choice;
	system("cls");
	switch (choice)
	{
	case 0:
		cout << "Exit." << endl;
		return 0;

	case 1:
		cout << "Enter the value of the vertex : ";
		cin >> value;
		if(tree.Find(value, tree.root))
		{
			system("cls");
			cout << "Such vertex already exists." << endl;
		}
		tree.root = tree.Insert(value, tree.root);
		system("pause");
		return 1;

	case 2:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "Enter the value of the vertex : ";
		cin >> value;
		if(!tree.Find(value, tree.root))
		{
			system("cls");
			cout << "Such vertex does NOT exist." << endl;
		}
		tree.root = tree.Delete(value, tree.root);
		system("pause");
		return 1;

	case 3:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "Enter the value of the vertex : ";
		cin >> value;
		system("cls");
		tree.Find(value, tree.root) ? cout << "There is such vertex." : cout << "There is NOT such vertex.";
		cout << endl;
		system("pause");
		return 1;

	case 4:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "The smallest vertex : " << tree.FindMin(tree.root) << endl;
		system("pause");
		return 1;
		
	case 5:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		cout << "The largest vertex : " << tree.FindMax(tree.root) << endl;
		system("pause");
		return 1;
	
	case 6:
		if (!tree.root)
		{
			cout << "The tree is empty." << endl;
			system("pause");
			return 1;
		}
		else
		{
			cout << "\tTree" << endl << endl;
			tree.Print(tree.root);
			cout << endl;
		}
		system("pause");
		return 1;
		
	default:
		cout << "Unknown command." << endl;
		system("pause");
		return 1;
	}
}