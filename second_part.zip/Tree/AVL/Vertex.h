#pragma once
#include <iostream>
using namespace std;

class Vertex
{
public:
	int data, height;
	Vertex* left, * right;
	Vertex(int data)
	{
		this->data = data; 
		left = nullptr;
		right = nullptr;
		height = 1;
	}
};