#include "UI.h"

int main()
{
	AVL tree;
	while (UI(tree));
	return 0;
}