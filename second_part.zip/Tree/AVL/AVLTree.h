#pragma once
#include "Vertex.h"

int tabs = 0;

class AVL
{
public:
	Vertex* root;
	AVL();
	Vertex* Insert(int data, Vertex* pos);
	Vertex* Delete(int data, Vertex* pos);
	Vertex* RR(Vertex* pos);
	Vertex* RL(Vertex* pos);
	Vertex* LL(Vertex* pos);
	Vertex* LR(Vertex* pos);
	bool Find(int data, Vertex* pos);
	int FindMin(Vertex* pos);
	int FindMax(Vertex* pos);
	int Height(Vertex* pos);
	void Print(Vertex* pos);
};

AVL::AVL()
{
	cout << "Creating the tree..." << endl;
	root = nullptr;
	cout << "Tree was created." << endl;
}

Vertex* AVL::Insert(int data, Vertex* pos)
{
	if (!pos)
	{
		Vertex* temp = new Vertex(data);
		pos = temp;
		if (!pos) return nullptr;
	}
	else
	{
		if(data < pos->data)
		{
			pos->left = Insert(data, pos->left);
			if(Height(pos->left) - Height(pos->right) == 2)
			{
				if(data < pos->left->data)
				{
					pos = LL(pos);
				}
				if(data > pos->left->data)
				{
					pos = LR(pos);
				}
			}
		}
		if (data > pos->data)
		{
			pos->right = Insert(data, pos->right);
			if(Height(pos->right) - Height(pos->left) == 2)
			{
				if(data > pos->right->data)
				{
					pos = RR(pos);				
				}
				if(data < pos->right->data)
				{
					pos = RL(pos);
				}
			}
		}
	}
	pos->height = max(Height(pos->left), Height(pos->right)) + 1;
	return pos;
}

Vertex* AVL::Delete(int data, Vertex* pos)
{
	if(!pos)
	{
		return nullptr;
	}
	if(data == pos->data)
	{
		Vertex* temp;
		if(!pos->left)
		{	
			temp = pos->right;
			delete pos;
			return temp;
		}
		if (!pos->right)
		{ 
			temp = pos->left;
			delete pos;
			return temp;
		}
		for(temp = pos->left; temp->right; temp = temp->right);
		pos->data = temp->data;
		pos->left = Delete(temp->data, pos->left);
	}
	else
	{
		if(data < pos->data)
		{
			pos->left = Delete(data, pos->left);
			if(Height(pos->right) - Height(pos->left) == 2)
			{
				if(Height(pos->right->right) >= Height(pos->right->left))
				{
					pos = RR(pos);	
				}
				if(Height(pos->right->right) < Height(pos->right->left))
				{
					pos = RL(pos);
				}
			}
		}
		if(data > pos->data)
		{
			pos->right = Delete(data, pos->right);
			if(Height(pos->left) - Height(pos->right) == 2)
			{
				if(Height(pos->left->right) <= Height(pos->left->left))				
				{
					pos = LL(pos);			
				}
				if(Height(pos->left->right) > Height(pos->left->left))
				{
					pos = LR(pos);
				}
			}
		}
	}
	pos->height = max(Height(pos->left), Height(pos->right)) + 1;
	return pos;
}

Vertex* AVL::RR(Vertex* pos)
{
	Vertex* temp = pos->right;
	pos->right = temp->left;
	temp->left = pos;
	pos->height = max(Height(pos->left), Height(pos->right)) + 1;
	temp->height = max(Height(pos), Height(temp->right)) + 1;
	return temp;
}

Vertex* AVL::LL(Vertex* pos)
{
	Vertex* temp = pos->left;
	pos->left = temp->right;
	temp->right = pos;
	pos->height = max(Height(pos->left), Height(pos->right)) + 1;
	temp->height = max(Height(pos), Height(temp->left)) + 1;
	return temp;
}

Vertex* AVL::RL(Vertex* pos)
{
	pos->right = LL(pos->right);
	return RR(pos);
}

Vertex* AVL::LR(Vertex* pos)
{
	pos->left = RR(pos->left);
	return LL(pos);
}

bool AVL::Find(int data, Vertex* pos)
{
	if(!pos)
	{
		return false;
	}
	if(data > pos->data)
	{
		return Find(data, pos->right);
	}
	else
	{
		if(data < pos->data)
		{
			return Find(data, pos->left);
		}
		else
		{
			return true;
		}
	}
}

int AVL::FindMin(Vertex* pos)
{
	if(!pos)
	{
		return 0;
	}
	Vertex* temp = pos;
	while(temp->left)
		temp = temp->left;
	return temp->data;
}


int AVL::FindMax(Vertex* pos)
{
	if(!pos)
	{
		return 0;
	}
	Vertex* temp = pos;
	while(temp->right)
		temp = temp->right;
	return temp->data;
}

int AVL::Height(Vertex* pos)
{
	if(!pos)
	{
		return 0;
	}
	else
	{
		return pos->height;
	}
}

void AVL::Print(Vertex* pos)
{
	if (!pos) return;
	tabs += 5;
	Print(pos->right);
	for (int i = 0; i < tabs; i++) cout << " ";
	cout << pos->data << endl;
	Print(pos->left);
	tabs -= 5;
	return;
}