#include <iostream>
using namespace std;

#define SIZE 4

class Set
{
	int size, index;
	int* s;
	bool* b;
public:
	Set();
	~Set();
	void Push(int number);
	void Pop(int& number);
	void Delete(int number);
	bool Find(int number);
	bool IsSpace();
	bool IsEmpty();
	void Show();
	int GetElement(int index);
};

Set::Set()
{
	cout << "Constructing the set..." << endl;
	size = index = 0;
	s = new int[SIZE];
	b = new bool[SIZE];
	for(int i = 0; i < SIZE; i++)
	{
		*(b + i) = true;
	}
	cout << "The set was created." << endl;
}

Set::~Set()
{
	cout << "Deleting the set..." << endl;
	delete [] s;
	cout << "The set was deleted." << endl;
}

void Set::Push(int number)
{
	if(!IsSpace())
	{
		cout << "The set is full." << endl;
		return;
	}
	for(int i = 0; i < SIZE; i++)
	{
		if(*(b + i))
		{
			*(s + i) = number;
			*(b + i) = false;
			size++;
			cout << "Element was added." << endl;
			break;
		}
	}
}

void Set::Pop(int& number)
{
	if(IsEmpty())
	{
		cout << "The set is empty." << endl;
		return;
	}
	for(int i = 0; i < SIZE; i++)
	{
		if(!(*(b + i)) && (*(s + i) == number))
		{
			number = *(s + i);
			*(b + i) = true;
			size--;
			cout << "Element was popped." << endl;
			break;
		}
	}
}

void Set::Delete(int number)
{
	if(IsEmpty())
	{
		cout << "The set is empty." << endl;
		return;
	}
	for(int i = 0; i < SIZE; i++)
	{
		if(!(*(b + i)) && *(s + i) == number)
		{
			*(b + i) = true;
			size--;
			cout << "Element was deleted." << endl;
			break;
		}
	}
}

bool Set::Find(int number)
{
	for(int i = 0; i < SIZE; i++)
	{
		if(!(*(b + i)) && *(s + i) == number)
			return true;
	}
	return false;
}

bool Set::IsSpace()
{
	return (size != SIZE);
}

bool Set::IsEmpty()
{
	return (!size);
}

int Set::GetElement(int index)
{	
	return (!(*(b + index))) ? *(s + index) : 0;
}

void Set::Show()
{
	cout << "The size of the set: " << size << endl;
	cout << endl;
	for(int i = 0; i < SIZE; i++)
	{
		if(!(*(b + i)))
			cout << *(s + i) << ",\t";
	}
	cout << endl;
}

// Пользовательский интерфейс.
int UI(int choice, Set& object)
{
	int number = 0;
	system("cls");
	cout << " 0. Exit." << endl;
	cout << " 1. Add the element." << endl;								// Добавить элемент.
	cout << " 2. Take the element." << endl;							// Взять элемент.
	cout << " 3. Delete the element." << endl;							// Удалить элемент.
	cout << " 4. Find the element." << endl; 							// Найти элемент.
	cout << " 5. Is the set empty?" << endl;							// Множество пуст?
	cout << " 6. Is there place in the set?" << endl;					// Есть ли место в множестве?
	cout << endl;
	object.Show();
	cout << endl;
	cout << "Enter the number of command: ";
	cin >> choice;
	system("cls");
	switch(choice) {
		case 0 :
			return 0;
			
		case 1 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.Push(number);
			system("pause");
			return 1;
			
		case 2 :
			if(!object.IsEmpty())
			{	
				cin >> number;
				if(object.Find(number))
				{
					object.Pop(number);
					cout << "The popped element: " << number << endl;
				}
			}
			else
				cout << "The set is empty." << endl;
			system("pause");
			return 1;
		
		case 3 :
			if(!object.IsEmpty())
			{	
				cin >> number;
				if(object.Find(number))
					object.Delete(number);
			}
			else
				cout << "The set is empty." << endl;
			system("pause");
			return 1;
		
		case 4 :
			if(!object.IsEmpty())
			{
				cin >> number;
				if(object.Find(number))
					cout << "There is such element." << endl;
				else
					cout << "There is not such element." << endl;
			}
			else
				cout << "The set is empty." << endl;
			
			system("pause");
			return 1;
			
		case 5 :
			if(object.IsSpace())
				cout << "There is place in the set." << endl;
			else
				cout << "The set is full." << endl;
			system("pause");
			return 1;
			
		case 6 :
			if(object.IsEmpty())
				cout << "The set is empty." << endl;
			else
				cout << "There is place in the set." << endl;
			system("pause");
			return 1;
			
			
		default :
			cout << "Unknown command." << endl;
			system("pause");
			return 1;
	}
}

int main()
{
	int choice = 0;
	Set st;
	while (UI(choice, st));
	return 0;
}
