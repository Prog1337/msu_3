﻿#include <iostream>
#include <cstring>
using namespace std;

class Weapon {
protected:
	string weaponName;
	bool scopeAvailability;
	int weaponDamage;
	int weaponPrice;
	double reloadTime;
public:
	Weapon(string name, bool scope, int damage, int price, double reload) {
		weaponName = name;
		scopeAvailability = scope;
		weaponDamage = damage;
		weaponPrice = price;
		reloadTime = reload;
	}
	~Weapon()	{}
	void ShowBasic() {
		cout << "Name " << weaponName << endl;
		scopeAvailability ? cout << "Scope is available" << endl : cout << "Scope is unavailable" << endl;
		cout << "Damage " << weaponDamage << endl;
		cout << "Price " << weaponPrice << endl;
		cout << "Reload time " << reloadTime << endl;
	}
};

class WeaponWithScope : public Weapon {
	int zoomMultiplicity;
public:
	WeaponWithScope() : Weapon("AWP", true, 0, 0, 3.7) {
		zoomMultiplicity = 2;
	}
	WeaponWithScope(int multiplicity, string name, bool scope, int damage, int price, double reload) : Weapon(name, scope, damage, price, reload) {
		zoomMultiplicity = multiplicity;
	}
	~WeaponWithScope()	{}
	void ShowScope() {
		ShowBasic();
		cout << "Zoom " << zoomMultiplicity << endl;
	}
	WeaponWithScope operator +(WeaponWithScope rifle);
	WeaponWithScope operator =(WeaponWithScope rifle);
};

WeaponWithScope WeaponWithScope	:: operator +(WeaponWithScope rifle) {
	WeaponWithScope temp;
	temp.weaponDamage = weaponDamage + rifle.weaponDamage;
	temp.weaponPrice = weaponPrice + rifle.weaponPrice;
	return temp;
}

WeaponWithScope WeaponWithScope :: operator =(WeaponWithScope rifle) {
	weaponName = "G3SG1";
	scopeAvailability = rifle.scopeAvailability;
	weaponDamage = rifle.weaponDamage;
	weaponPrice = rifle.weaponPrice;
	reloadTime = rifle.reloadTime;
	return *this;
}

int main() {
	Weapon Glock("Glock-18", false, 30, 200, 2.27);
	Glock.ShowBasic();
	cout << endl;
	WeaponWithScope SSG(2, "SSG 08", true, 85, 1700, 3.7);
	SSG.ShowScope();
	cout << endl;
	WeaponWithScope SG(2, "SG 553", true, 30, 3050, 2.77);
	SG.ShowScope();
	cout << endl;
	WeaponWithScope AWP;
	AWP = SSG + SG;
	AWP.ShowScope();
	cout << endl;
	WeaponWithScope SCAR(2, "SCAR-20", true, 80, 5000, 3.1);
	SCAR.ShowScope();
	cout << endl;
	WeaponWithScope G3SG1;
	G3SG1 = SCAR;
	G3SG1.ShowScope();
	cout << endl;
	return 0;
}
