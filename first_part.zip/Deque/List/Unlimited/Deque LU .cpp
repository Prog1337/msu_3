#include <iostream>
#include <conio.h>
using namespace std;

class Element
{
public:
	int value;
	Element* next, * prev;
	Element(int value, Element* next = nullptr, Element* prev = nullptr)
	{
		this->value = value;
		this->next = next;
		this->prev = prev;
	}
};

class Dequeue
{
	int size;
	Element* head, * tail;
public:
	Dequeue();															// Создать дек.
	~Dequeue();															// Уничтожить дек.
	void PushHead(int value);											// Добавить элемент в начало дека.
	void PushTail(int value);											// Добавить элемент в конец дека.
	int PopHead(int& value);											// Взять элемент из начала дека.
	int PopTail(int& value);											// Взять элемент из конца дека.
	int DeleteHead(int variable = 0);									// Удалить элемент из начала дека.
	int DeleteTail(int variable = 0);									// Удалить элемент из конца дека.
	int EditAt(int value, int index);									// Изменить указанный элемент.
	int Clear();														// Очистить дек.
	bool IsEmpty();														// Дек пуст?
	int GetSize() { return size; }										// Получить значение длины дека.
	int& operator [](int index);									// Перегрузка оператора индексации.
	void Show();														// Показать дек.
};

// Создать дек.
Dequeue::Dequeue()
{
	cout << "Constructing the deque..." << endl;
	size = 0;
	head = nullptr;
	tail = nullptr;
	cout << "The deque was created." << endl;
}

// Уничтожить дек.
Dequeue::~Dequeue()
{
	cout << "Deleting the deque..." << endl;
	delete[] head;
	delete[] tail;
	cout << "The deque was deleted." << endl;
}

// Добавить элемент в начало дека.
void Dequeue::PushHead(int value)
{
	Element* temp = new Element(value, head);
	if (head != nullptr)
	{
		head->prev = temp;
		head = temp;
	}
	else
		head = tail = temp;
	size++;
}

// Добавить элемент в конец дека.
void Dequeue::PushTail(int value)
{
	Element* temp = new Element(value, nullptr, tail);
	if (tail != nullptr)
	{
		tail->next = temp;
		tail = temp;
	}
	else
		head = tail = temp;
	size++;
}

// Взять элемент из начала дека.
int Dequeue::PopHead(int& value)
{
	if(!size)
	{
		value = -1;		//	не хочу, чтобы был мусор
		return 0;
	}
	else if(size == 1)
	{
		value = head->value;
		delete head;
		head = tail = nullptr;
		size--;
		return 1;
	}
	else
	{
		Element* temp = head;
		value = temp->value;
		head = head->next;
		delete temp;
		size--;
		return 1;
	}
}

// Взять элемент из конца дека.
int Dequeue::PopTail(int& value)
{
	if(!size)
	{
		value = -1;		//	не хочу, чтобы был мусор
		return 0;
	}
	else if(size == 1)
	{
		value = head->value;
		delete head;
		head = tail = nullptr;
		size--;
		return 1;
	}
	else
	{
		Element* temp = tail;
		value = temp->value;
		tail = tail->prev;
		delete temp;
		size--;
		return 1;
	}
}

// Удалить элемент из начала дека.
int Dequeue::DeleteHead(int variable)
{
	return PopHead(variable);
}

// Удалить элемент из конца дека.
int Dequeue::DeleteTail(int variable)
{
	return PopTail(variable);
}

// Изменить указанный элемент.
int Dequeue::EditAt(int value, int index)
{
	if (size)
	{
		(*this)[index] = value;
		return 1;
	}
	else
		return 0;
}

// Очистить дек.
int Dequeue::Clear()
{
	int i = 0;
	while(i < size - 1)
		DeleteHead();
	return DeleteHead();
}

// Дек пуст?
bool Dequeue::IsEmpty()
{
	return (head == nullptr && tail == nullptr)?	true : false;
}

// Перегрузка оператора индексации.
int& Dequeue::operator [](int index)
{
	Element* current = this->head;
	int counter = 0;
	while (current->next != nullptr)
	{
		if (counter == index)
			return current->value;
		current = current->next;
		counter++;
	}
	return current->value;
}

// Показать дек.
void Dequeue::Show()
{
	cout << "The deque with the length of " << size << " elements:" << endl;
	if(size == 1)
		cout << (*this)[0];
	if(size > 1)
	{
		for(int i = 1; i < size + 1; i++)
		{
			if(i  % 10 != 0)
				cout << (*this)[i - 1] << "\t";
			else
				cout << (*this)[i - 1] << endl;
		}
	}
	cout << endl;
}

// Пользовательский интерфейс.
int UI(int choice, Dequeue &object)
{
	int number = 0;
	system("cls");
	cout << "  0. Exit." << endl;
	cout << "  1. Add the element to the front of the deque." << endl;				// Добавить элемент в начало дека.
	cout << "  2. Add the element to the back of the deque." << endl;				// Добавить элемент в конец дека.
	cout << "  3. Take the element from the head of the deque." << endl;			// Взять элемент из начала дека.
	cout << "  4. Take the element from the back of the deque." << endl;			// Взять элемент из конца дека.
	cout << "  5. Delete the element from the front of the deque." << endl;			// Удалить элемент из начала дека.
	cout << "  6. Delete the element from the back of the deque." << endl;			// Удалить элемент из конца дека.
	cout << "  7. Edit the certain element of the deque." << endl;					// Изменить указанный элемент.
	cout << "  8. Print the certain element of the deque." << endl;					// Показать указанный элемент.
	cout << "  9. Clear the deque." << endl;										// Очистить дек.
	cout << " 10. Is the deque empty?" << endl;										// Дек пуст?
	cout << " 11. Show the deque." << endl;											// Показать дек.
	cout << endl;
	if(object.IsEmpty() == false)
		object.Show();
	cout << endl;
	cout << "Enter the number of command: ";
	cin >> choice;
	system("cls");
	switch(choice) {
		case 0 : {
			return 0;
		}
		case 1 : {
			cout << "Enter the value: ";
			cin >> number;
			object.PushHead(number);
			cout << "The element was added to the front of the deque." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 2 : {
			cout << "Enter the value: ";
			cin >> number;
			object.PushTail(number);
			cout << "The element was added to the back of the deque." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}	
		case 3 : {
			if(object.PopHead(number)) {
				if(number != -1)
					cout << number <<  " was popped from the front of the deque." << endl;
			}
			else
				cout << "The deque is empty." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 4 : {
			if(object.PopTail(number)) {
				if(number != -1)
					cout << number << " was popped from the back of the deque." << endl;
			}
			else
				cout << "The deque is empty." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 5 : {
			if(object.DeleteHead())
				cout << "The element in the front of the deque was deleted." << endl;
			else
				cout << "The deque is empty." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 6 : {
			if (object.DeleteTail())
				cout << "The element in the back of the deque was deleted." << endl;
			else
				cout << "The deque is empty." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 7 : {
			int index;
			cout << "Enter the index of the element: ";
			cin >> index;
			if(index >= object.GetSize())
			{
				cout << "The element does not exist." << endl;
				cout << endl << "Press any button." << endl;
				getch();
				return 1;
			}
			cout << "Enter the new value of the element : ";
			cin >> number;
			if(object.EditAt(number, index))
				cout << "The element was edited by " << object[index] << "." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
			
		}
		case 8 : {
			cout << "Enter the index: ";
			cin >> number;
			if(number >= 0 && number < object.GetSize())
				cout << object[number] << endl;
			else
				cout << "The element does not exist." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 9 : {
			if(object.Clear())
				cout << "The deque was cleared." << endl;
			else
				cout << "The deque is already clear." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 10 : {
			if(object.IsEmpty())
				cout << "The deque is empty." << endl;
			else
				cout << "The deque is not empty." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		case 11 : {
			if(!object.IsEmpty())
				object.Show();
			else
				cout << "The deque is empty." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
		default : {
			cout << "Unknown command." << endl;
			cout << endl << "Press any button." << endl;
			getch();
			return 1;
		}
	}
}

int main()
{
	int choice = 0;
	Dequeue dq;
	while (UI(choice, dq));
	return 0;
}
