#include <iostream>
using namespace std;

#define SIZE 4															// Проверял на малых размерностях
#define tabs 10															// Для отступов			

class Element
{
public:
	int value;
	Element* next, * prev;
};

class Dequeue
{
	int size;
	Element* head, * tail, * mem, * endmem;
public:
	Dequeue();															// Создать дек.
	~Dequeue();															// Уничтожить дек.
	void PushFront(int value);											// Добавить элемент в начало дека.
	void PushBack(int value);											// Добавить элемент в конец дека.
	void PopFront(int& value);											// Взять элемент из начала дека.
	void PopBack(int& value);											// Взять элемент из конца дека.
	void DeleteFront();													// Удалить элемент из начала дека.
	void DeleteBack();													// Удалить элемент из конца дека.
	void PrintFront();													// Прочитать начало дека.
	void PrintBack();													// Прочитать конец дека.
	void EditFront(int value);											// Изменить элемент в начале дека.
	void EditBack(int value);											// Изменить элемент в конце дека.
	void Clear();														// Очистить дек.
	bool IsEmpty();														// Дек пуст?
	bool IsSpace();														// Есть ли место в деке?
	int GetSize();														// Получить значение длины дека.
	void Show();														// Показать дек.
};

// Создать дек.
Dequeue::Dequeue()
{
	cout << "Constructing the deque..." << endl;
	mem = new Element[SIZE];
	endmem = mem;
	for(int i = 1; i < SIZE; i++)
	{
		endmem->next = endmem + 1;
		(endmem + 1)->prev = endmem;
		endmem = endmem->next;
	}
	endmem->next = mem;
	mem->prev = endmem;
	head = mem;
	tail = endmem;
	size = 0;
	cout << "The deque was created." << endl;
}

// Уничтожить дек.
Dequeue::~Dequeue()
{
	cout << "Deleting the deque..." << endl;
	delete [] mem;
	cout << "The deque was deleted." << endl;
}

// Добавить элемент в начало дека.
void Dequeue::PushFront(int value)
{
	if(!IsSpace())
	{
		cout << "The deque is full." << endl;
		return;
	} 
	head = head->prev;
	head->value = value;
	size++;
	cout << "The element was added to the front." << endl;
}

// Добавить элемент в конец дека.
void Dequeue::PushBack(int value)
{
	if(!IsSpace())
	{
		cout << "The deque is full." << endl;
		return;
	}
	tail = tail->next;
	tail->value = value;
	size++;
	cout << "The element was added to the back." << endl;
}

// Взять элемент из начала дека.
void Dequeue::PopFront(int& value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	value = head->value;
	head = head->next;
	size--;
	cout << "The element was popped from the front." << endl;
}

// Взять элемент из конца дека.
void Dequeue::PopBack(int& value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	value = tail->value;
	tail = tail->prev;
	size--;
	cout << "The element was popped from the back." << endl;
}

// Удалить элемент из начала дека.
void Dequeue::DeleteFront()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	head = head->next;
	size--;
	cout << "The element was deleted from the front." << endl;
}

// Удалить элемент из конца дека.
void Dequeue::DeleteBack()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	tail = tail->prev;
	size--;
	cout << "The element was deleted from the back." << endl;
}

// Прочитать начало дека.
void Dequeue::PrintFront()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The front: " << head->value << endl;
}

// Прочитать конец дека.
void Dequeue::PrintBack()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The back: " << tail->value << endl;
}

// Изменить элемент в начале дека.
void Dequeue::EditFront(int value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	head->value = value;
}

// Изменить элемент в конце дека.
void Dequeue::EditBack(int value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	tail->value = value;
}

// Очистить дек.
void Dequeue::Clear()
{
	head = mem;
	tail = endmem;
	size = 0;
	cout << "Deque is clear." << endl;
}

// Дек пуст?
bool Dequeue::IsEmpty()
{
	return (!size);
}

// Есть ли место в деке?
bool Dequeue::IsSpace()
{
	return (size != SIZE);
}

// Получить значение длины дека.
int Dequeue::GetSize()
{
	return size;
}

// Показать дек.
void Dequeue::Show()
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The length of the deque: " << size << endl;
	int i = 1;
	for(Element* cur = head; i < size + 1; cur = cur->next)
	{
		if(i % tabs != 0)
			cout << cur->value << "\t";
		else
			cout << cur->value << endl;
		i++;
	}
	cout << endl;
}

// Пользовательский интерфейс.
int UI(Dequeue& dq)
{
	int choice, number;
	system("cls");
	cout << "  0. Exit." << endl;
	cout << "  1. Add the element to the front of the deque." << endl;				// Добавить элемент в начало дека.
	cout << "  2. Add the element to the back of the deque." << endl;				// Добавить элемент в конец дека.
	cout << "  3. Take the element from the head of the deque." << endl;			// Взять элемент из начала дека.
	cout << "  4. Take the element from the back of the deque." << endl;			// Взять элемент из конца дека.
	cout << "  5. Delete the element from the front of the deque." << endl;			// Удалить элемент из начала дека.
	cout << "  6. Delete the element from the back of the deque." << endl;			// Удалить элемент из конца дека.
	cout << "  7. Print the front of the deque." << endl; 							// Прочитать начало дека.
	cout << "  8. Print the back of the deque." << endl;							// Прочитать конец дека.
	cout << "  9. Edit the front of the deque." << endl;							// Изменить элемент в начале дека.
	cout << " 10. Edit the back of the deque." << endl;								// Изменить элемент в конце дека.
	cout << " 11. Clear the deque." << endl;										// Очистить дек.
	cout << " 12. Is the deque empty?" << endl;										// Дек пуст?
	cout << " 13. Is there place in the deque?" << endl;							// Есть ли место в деке?
	cout << endl;
	dq.Show();
	cout << endl;
	cout << "Enter the number of command: ";
	cin >> choice;
	system("cls");
	switch(choice) {
		case 0 :
			return 0;
			
		case 1 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			dq.PushFront(number);
			system("pause");
			return 1;
			
		case 2 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			dq.PushBack(number);
			system("pause");
			return 1;
			
		case 3 :
			if(!dq.IsEmpty())
			{
				dq.PopFront(number);
				cout << "The popped element: " << number << endl;
			}
			else
			{
				cout << "The deque is empty." << endl;
			}
			system("pause");
			return 1;
		
		case 4 :
			if(!dq.IsEmpty())
			{
				dq.PopBack(number);
				cout << "The popped element: " << number << endl;
			}
			else
			{
				cout << "The deque is empty." << endl;
			}
			system("pause");
			return 1;
		
		case 5 : 
			dq.DeleteFront();
			system("pause");
			return 1;
		
		case 6 : 
			dq.DeleteBack();
			system("pause");
			return 1;

		case 7:
			dq.PrintFront();
			system("pause");
			return 1;
			
		case 8:
			dq.PrintBack();
			system("pause");
			return 1;

		case 9:
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			dq.EditFront(number);
			system("pause");
			return 1;
		
		case 10:
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			dq.EditBack(number);
			system("pause");
			return 1;

		case 11 :
			dq.Clear();
			system("pause");
			return 1;
			
		case 12 :
			if(dq.IsEmpty())
				cout << "The deque is empty." << endl;
			else
				cout << "There is place in the deque." << endl;
			system("pause");
			return 1;
			
		case 13 :
			if(dq.IsSpace())
				cout << "There is place in the deque." << endl;
			else
				cout << "The deque is full." << endl;
			system("pause");
			return 1;
			
		default :
			cout << "Unknown command." << endl;
			system("pause");
			return 1;
	}
}

int main()
{
	Dequeue dq;
	while (UI(dq));
	return 0;
}
