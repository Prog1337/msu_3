#include <iostream>
using namespace std;

#define SIZE 100														// Проверял на малых размерностях
#define tabs 10															// Для отступов			
	
class Element
{
public:
	int value;
	Element* next, * prev;
	Element(int value, Element* next = NULL, Element* prev = NULL)
	{
		this->value = value;
		this->next = next;
		this->prev = prev;
	}
};

class Dequeue
{
	int size;
	Element* head, * tail;
public:
	Dequeue();															// Создать дек.
	~Dequeue();															// Уничтожить дек.
	void PushFront(int value);											// Добавить элемент в начало дека.
	void PushBack(int value);											// Добавить элемент в конец дека.
	void PopFront(int& value);											// Взять элемент из начала дека.
	void PopBack(int& value);											// Взять элемент из конца дека.
	void DeleteFront();													// Удалить элемент из начала дека.
	void DeleteBack();													// Удалить элемент из конца дека.
	void PrintFront();													// Прочитать начало дека.
	void PrintBack();													// Прочитать конец дека.
	void EditFront(int value);											// Изменить элемент в начале дека.
	void EditBack(int value);											// Изменить элемент в конце дека.
	void Clear();														// Очистить дек.
	bool IsEmpty();														// Дек пуст?
	bool IsSpace();														// Есть ли место в деке?
	int GetSize();														// Получить значение длины дека.
	int& operator [](int index);										// Перегрузка оператора индексации.
};

// Создать дек.
Dequeue::Dequeue()
{
	cout << "Constructing the deque..." << endl;
	size = 0;
	head = NULL;
	tail = NULL;
	cout << "The deque was created." << endl;
}

// Уничтожить дек.
Dequeue::~Dequeue()
{
	cout << "Deleting the deque..." << endl;
	delete[] head;
	delete[] tail;
	cout << "The deque was deleted." << endl;
}


// Добавить элемент в начало дека.
void Dequeue::PushFront(int value)
{
	if(!IsSpace())
	{
		cout << "The deque is full." << endl;
		return;
	}
	Element* temp = new Element(value, head);
	if (!head)
		head = tail = temp;
	else
	{
		head->prev = temp;
		head = temp;
	}
	size++;
	cout << "The element was added to the front." << endl;
}

// Добавить элемент в конец дека.
void Dequeue::PushBack(int value)
{
	if(!IsSpace())
	{
		cout << "The deque is full." << endl;
		return;
	}
	Element* temp = new Element(value, NULL, tail);
	if (!tail)
		head = tail = temp;
	else
	{
		tail->next = temp;
		tail = temp;
	}
	size++;
	cout << "The element was added to the back." << endl;
}

// Взять элемент из начала дека.
void Dequeue::PopFront(int& value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	if(size == 1)
	{
		value = head->value;
		delete head;
		head = tail = NULL;
	}
	else
	{
		Element* temp = head;
		value = temp->value;
		head = head->next;
		delete temp;
	}
	size--;
	cout << "The element was popped from the front." << endl;
}

// Взять элемент из конца дека.
void Dequeue::PopBack(int& value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	if(size == 1)
	{
		value = head->value;
		delete head;
		head = tail = NULL;
	}
	else
	{
		Element* temp = tail;
		value = temp->value;
		tail = tail->prev;
		delete temp;
	}
	size--;
	cout << "The element was popped from the back." << endl;
}

// Удалить элемент из начала дека.
void Dequeue::DeleteFront()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	if(size == 1)
	{
		delete head;
		head = tail = NULL;
	}
	else
	{
		Element* temp = head;
		head = head->next;
		delete temp;
	}
	size--;
	cout << "The element was deleted from the front." << endl;
}

// Удалить элемент из конца дека.
void Dequeue::DeleteBack()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	if(size == 1)
	{
		delete head;
		head = tail = NULL;
	}
	else
	{
		Element* temp = tail;
		tail = tail->prev;
		delete temp;
	}
	size--;
	cout << "The element was deleted from the back." << endl;
}

// Прочитать начало дека.
void Dequeue::PrintFront()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The front: " << head->value << endl;
}

// Прочитать конец дека.
void Dequeue::PrintBack()
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The back: " << tail->value << endl;
}

// Изменить элемент в начале дека.
void Dequeue::EditFront(int value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	head->value = value;
}

// Изменить элемент в конце дека.
void Dequeue::EditBack(int value)
{
	if(IsEmpty())
	{
		cout << "The deque is empty." << endl;
		return;
	}
	tail->value = value;
}

// Очистить дек.
void Dequeue::Clear()
{
	while(size)
		DeleteFront();
	system("cls");
	cout << "Deque is clear." << endl;
}

// Дек пуст?
bool Dequeue::IsEmpty()
{
	return (!size);
}

// Есть ли место в деке?
bool Dequeue::IsSpace()
{
	return (size != SIZE);
}

// Получить значение длины дека.
int Dequeue::GetSize()
{
	return size;
}

// Перегрузка оператора индексации.
int& Dequeue::operator [](int index)
{
	Element* current = head;
	int counter = 0;
	while (current->next)
	{
		if (counter == index)
			return current->value;
		current = current->next;
		counter++;
	}
	return current->value;
}

// Пользовательский интерфейс.
int UI(int choice, Dequeue& object)
{
	int number = 0;
	system("cls");
	cout << "  0. Exit." << endl;
	cout << "  1. Add the element to the front of the deque." << endl;				// Добавить элемент в начало дека.
	cout << "  2. Add the element to the back of the deque." << endl;				// Добавить элемент в конец дека.
	cout << "  3. Take the element from the head of the deque." << endl;			// Взять элемент из начала дека.
	cout << "  4. Take the element from the back of the deque." << endl;			// Взять элемент из конца дека.
	cout << "  5. Delete the element from the front of the deque." << endl;			// Удалить элемент из начала дека.
	cout << "  6. Delete the element from the back of the deque." << endl;			// Удалить элемент из конца дека.
	cout << "  7. Print the certain element of the deque." << endl;					// Показать указанный элемент.
	cout << "  8. Print the front of the deque." << endl; 							// Прочитать начало дека.
	cout << "  9. Print the back of the deque." << endl;							// Прочитать конец дека.
	cout << " 10. Edit the certain element of the deque." << endl;					// Изменить указанный элемент.
	cout << " 11. Edit the front of the deque." << endl;							// Изменить элемент в начале дека.
	cout << " 12. Edit the front of the deque." << endl;							// Изменить элемент в конце дека.
	cout << " 13. Clear the deque." << endl;										// Очистить дек.
	cout << " 14. Is the deque empty?" << endl;										// Дек пуст?
	cout << " 15. Is there place in the deque?" << endl;							// Есть ли место в деке?
	cout << endl;
	cout << "Enter the number of command: ";
	cin >> choice;
	system("cls");
	switch(choice) {
		case 0 :
			return 0;
			
		case 1 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.PushFront(number);
			system("pause");
			return 1;
			
		case 2 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.PushBack(number);
			system("pause");
			return 1;
			
		case 3 :
			if(!object.IsEmpty())
			{
				object.PopFront(number);
				cout << "The popped element: " << number << endl;
			}
			else
			{
				cout << "The deque is empty." << endl;
			}
			system("pause");
			return 1;
		
		case 4 :
			if(!object.IsEmpty())
			{
				object.PopBack(number);
				cout << "The popped element: " << number << endl;
			}
			else
			{
				cout << "The deque is empty." << endl;
			}
			system("pause");
			return 1;
		
		case 5 : 
			object.DeleteFront();
			system("pause");
			return 1;
		
		case 6 : 
			object.DeleteBack();
			system("pause");
			return 1;
			
		case 7 :
			if(!object.IsEmpty())
			{
				cout << "Enter the index: ";
				cin >> number;
				system("cls");
				if(number >= 0 && number < object.GetSize())
					cout << "The element : " << object[number] << endl;
				else
					cout << "The element does not exist." << endl;
			}
			else
				cout << "The deque is empty." << endl;
			system("pause");
			return 1;
			
		case 8:
			object.PrintFront();
			system("pause");
			return 1;
			
		case 9:
			object.PrintBack();
			system("pause");
			return 1;

		case 10:
			if(!object.IsEmpty())
			{
				int index;
				cout << "Enter the index of the element: ";
				cin >> index;
				system("cls");
				if(index < 0 || index >= object.GetSize())
				{
					cout << "The element does not exist." << endl;
					system("pause");
					return 1;
				}
				cout << "Enter the new value of the element : ";
				cin >> number;
				system("cls");
				object[index] = number;
				cout << "The element was edited by " << object[index] << "." << endl;
			}
			else 
				cout << "The deque is empty." << endl;
			system("pause");
			return 1;
			
		case 11:
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.EditFront(number);
			system("pause");
			return 1;
		
		case 12:
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.EditBack(number);
			system("pause");
			return 1;

		case 13 :
			object.Clear();
			system("pause");
			return 1;
			
		case 14 :
			if(object.IsEmpty())
				cout << "The deque is empty." << endl;
			else
				cout << "There is place in the deque." << endl;
			system("pause");
			return 1;
			
		case 15 :
			if(object.IsSpace())
				cout << "There is place in the deque." << endl;
			else
				cout << "The deque is full." << endl;
			system("pause");
			return 1;
			
		default :
			cout << "Unknown command." << endl;
			system("pause");
			return 1;
	}
}

int main()
{
	int choice = 0;
	Dequeue dq;
	while (UI(choice, dq));
	return 0;
}
