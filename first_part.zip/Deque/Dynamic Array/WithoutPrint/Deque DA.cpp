#include <iostream>
using namespace std;

#define SIZE 100								// Проверял на малых размерностях
#define tabs 10									// Для отступов

int mod(int a, int b)
{
	int result = a % b;
	if (result * b < 0)
		result += b;
	return result;
}

class Dequeue {
	int* dq;
public:
	int size, t, h;
	Dequeue();									// Создать дек.
	~Dequeue();									// Уничтожить дек.
	void PushFront(int value);					// Добавить элемент в начало дека.
	void PushBack(int value);					// Добавить элемент в конец дека.
	void PopFront(int &value);					// Взять элемент из начала дека.
	void PopBack(int &value);					// Взять элемент из конца дека.
	void DeleteFront();							// Удалить элемент из начала дека.
	void DeleteBack();							// Удалить элемент из конца дека.
	void PrintFront();							// Показать элемент из начала дека.
	void PrintBack();							// Показать элемент из конца дека.
	void EditFront(int value); 					// Изменить элемент в начале дека.
	void EditBack(int value);					// Изменить элемент в конце дека.
	void Clear();								// Очистить дек.
	bool IsSpace();								// Есть ли место в деке?
	bool IsEmpty();								// Дек пуст?
};

// Создать дек.
Dequeue::Dequeue()
{
	
	cout << "Creating the new deque..." << endl;
	dq = new int[SIZE];
	size = 0;
	cout << "The new deque was created." << endl;
}

// Уничтожить дек.
Dequeue::~Dequeue()										
{
	cout << "Deleting the deque..." <<endl;
	delete[] dq;
	cout << "The deque was deleted." << endl;
}

// Добавить элемент в начало дека.
void Dequeue::PushFront(int value)
{
	if(!IsSpace())
	{
		cout << "The deque is full." << endl;
		return;
	}
	if(!size) 
	{
		h = 0;
		t = 0;
	}
	else
		h = mod(h - 1, SIZE);
	*(dq + h) = value;
	size++;
	cout << "The element was added to the front." << endl;
}

// Добавить элемент в конец дека.
void Dequeue:: PushBack(int value)
{
	if(!IsSpace())
	{
		cout << "The deque is full." << endl;
		return;
	}
	if(!size) 
	{
		h = 0;
		t = 0;
	}
	else 
		t = mod(t + 1, SIZE);
	*(dq + t) = value;
	size++;
	cout << "The element was added to the back." << endl;
}

// Взять элемент из начала дека.
void Dequeue::PopFront(int &value)
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	value = *(dq + h);
	DeleteFront();
}

// Взять элемент из конца дека.
void Dequeue::PopBack(int &value)
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	value = *(dq + t);
	DeleteBack();
}

// Удалить элемент из начала дека.
void Dequeue::DeleteFront() 
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	h = mod(h + 1, SIZE);
	size--;
	cout << "The element was deleted from the front." << endl;
}

// Удалить элемент из конца дека.
void Dequeue::DeleteBack()
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	t = mod(t - 1, SIZE);
	size--;
	cout << "The element was deleted from the back." << endl;
}


// Показать элемент из начала дека.
void Dequeue::PrintFront()
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The front: " << *(dq + h) << endl;
}

// Показать элемент из конца дека.
void Dequeue::PrintBack()
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	cout << "The back:  " << *(dq + t) << endl;
}
	
// Изменить элемент в начале дека.
void Dequeue::EditFront(int value)
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	*(dq + h) = value;
}

// Изменить элемент в конце дека.
void Dequeue::EditBack(int value)
{
	if(IsEmpty()) 
	{
		cout << "The deque is empty." << endl;
		return;
	}
	*(dq + t) = value;
}

// Очистить дек.
void Dequeue::Clear()
{
	size = 0;
	cout << "Deque is clear." << endl;
}

// Есть ли место в деке?
bool Dequeue::IsSpace()
{
	return (size != SIZE);
}

// Дек пуст?
bool Dequeue::IsEmpty()
{
	return (!size);
}

// Пользовательский интерфейс.
int UI(int choice, Dequeue &object) {
	int number = 0;
	system("cls");
	cout << "  1. Add the element to the front of the deque." << endl;				// Добавить элемент в начало дека.
	cout << "  2. Add the element to the back of the deque." << endl;				// Добавить элемент в конец дека.
	cout << "  3. Take the element from the front of the deque." << endl;			// Взять элемент из начала дека.
	cout << "  4. Take the element from the back of the deque." << endl;			// Взять элемент из конца дека.
	cout << "  5. Delete the element from the front of the deque." << endl;			// Удалить элемент из начала дека.
	cout << "  6. Delete the element from the back of the deque." << endl;			// Удалить элемент из конца дека.
	cout << "  7. Print the front of the deque." << endl;							// Показать элемент из начала дека.
	cout << "  8. Print the back of the deque." << endl;							// Показать элемент из конца дека.
	cout << "  9. Edit the front of the deque." << endl;							// Изменить элемент в начале дека.
	cout << " 10. Edit the back of the deque." << endl;								// Изменить элемент в конце дека.
	cout << " 11. Clear the deque." << endl;										// Очистить дек.
	cout << " 12. Is there place in the deque?" << endl;							// Есть ли место в деке?
	cout << " 13. Is the deque empty?" << endl;										// Дек пуст?
	cout << "  0. Exit" << endl;
	cout << endl;
	cout << "Enter the number of command: ";
	cin >> choice;
	system("cls");
	switch(choice) {
		case 0 :
			return 0;
		
		case 1 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.PushFront(number);
			system("pause");
			return 1;
		
		case 2 :
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.PushBack(number);
			system("pause");
			return 1;
			
		case 3 :
			if(!object.IsEmpty())
			{
				object.PopFront(number);
				cout << "The deleted number: " << number << endl;
			}
			else
			{
				cout << "The deque is empty." << endl;
			}
			system("pause");
			return 1;
		
		case 4 :
			if(!object.IsEmpty())
			{
				object.PopBack(number);
				cout << "The deleted number: " << number << endl;
			}
			else
			{
				cout << "The deque is empty." << endl;
			}
			system("pause");
			return 1;
		
		case 5 : 
			object.DeleteFront();
			system("pause");
			return 1;
		
		case 6 : 
			object.DeleteBack();
			system("pause");
			return 1;

		case 7 :
			object.PrintFront();
			system("pause");
			return 1;
		
		case 8 : 
			object.PrintBack();
			system("pause");
			return 1;
		
		case 9 : 
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.EditFront(number);
			system("pause");
			return 1;
		
		case 10 : 
			cout << "Enter the value: ";
			cin >> number;
			system("cls");
			object.EditBack(number);
			system("pause");
			return 1;
		
		case 11 :
			object.Clear();
			system("pause");
			return 1;
			
		case 12 : 
			if(object.IsSpace())
				cout << "There is place in the deque." << endl;
			else
				cout << "The deque is full." << endl;
			system("pause");
			return 1;
		
		case 13 : 
			if(object.IsEmpty())
				cout << "The deque is empty." << endl;
			else
				cout << "The deque is not empty." << endl;
			system("pause");
			return 1;

		default : 
			cout << "Unknown command." << endl;
			system("pause");
			return 1;
	}
}

int main()
{
	int choice = 0;
	Dequeue deq;
	while (UI(choice, deq));
	return 0;
}
